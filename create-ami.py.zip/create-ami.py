import boto3
import datetime

region = 'us-east-1'
client = boto3.client('ec2', region)
backup_tag = 'Backup_jenkins'
expires_tag = 'Expires_jenkins'
expires_in_days = 3
expires_seconds = expires_in_days * 24 * 60 * 60


def create_ami_backups():
    now = datetime.datetime.now()
    start_date = str(datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    instances = []

    # get the list of reservations with the instances containing the tag Backup_jenkins=true
    reservations = client.describe_instances(Filters=[
        {
            'Name': 'tag:{0:s}'.format(backup_tag),
            'Values': ['true', 'True', 'yes', 'Yes']
        },
        {
            'Name': 'instance-state-name',
            'Values': ['running', 'stopped']
        }
    ]).get('Reservations', [])

    # retrieve the list of instances from reservations
    for r in reservations:
        for i in r['Instances']:
            instances.append(i)

    for instance in instances:
        instance_id = instance['InstanceId']
        name = 'AMI_{0:s}_{1:s}'.format(instance_id, start_date)
        description = 'AMI for {0:s} Created on: {1:s}'.format(instance_id, str(now))

        image = client.create_image(Description=description, InstanceId=instance_id, Name=name, NoReboot=True)
        print('Image id created: {0:s}'.format(image['ImageId']))

        add_expire_tag_to_ami(image, instance)


def add_expire_tag_to_ami(image, instance):
    now = datetime.datetime.now()
    timestamp = datetime.datetime.timestamp(now)

    tags = instance['Tags']
    tags.append({
        'Key': expires_tag,
        'Value': str(timestamp + expires_seconds),
    })
    client.create_tags(Resources=[image['ImageId']], Tags=tags)


def get_expire_tag(tags):
    expire_tag = [tag for tag in tags if 'Key' in tag and tag['Key'] == expires_tag]
    if len(expire_tag) == 1:
        return expire_tag[0]['Value']
    else:
        return None


def remove_old_amis():
    now = datetime.datetime.now()
    timestamp = datetime.datetime.timestamp(now)

    images = client.describe_images(Filters=[{
        'Name': 'tag:{0:s}'.format(backup_tag),
        'Values': ['true', 'True', 'yes', 'Yes']}
    ], Owners=['self'])
    for image in images['Images']:
        tags = image['Tags']
        image_id = image['ImageId']
        expire_tag_value = get_expire_tag(tags)

        if expire_tag_value and float(expire_tag_value) < timestamp:
            client.deregister_image(ImageId=image_id)
            print('Image id {0:s} has been deregistered'.format(image_id))

            remove_ebs_volumes(image)


def remove_ebs_volumes(image):
    block_device_mappings = image.get('BlockDeviceMappings')
    for device in block_device_mappings:
        snapshot = device.get('Ebs')
        if snapshot:
            snapshot_id = snapshot['SnapshotId']
            client.delete_snapshot(SnapshotId=snapshot_id)
            print('Snapshot id {0:s} has been removed'.format(snapshot_id))


def lambda_handler(event, context):
    create_ami_backups()
    remove_old_amis()
